#ifndef __GUI_COMMON_H__
#define __GUI_COMMON_H__
//void egui_set_transparent(eHandle, GuiWidget *);
//bool egui_pt_in_widget(eHandle, GuiWidget *wid, int x, int y);
//void egui_add_umask(eHandle, GuiWidget *wid, GalRect *prc);

#endif
